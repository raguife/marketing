// Simula a comunicação com o Code.gs (Google Apps Script)
export async function fetchData() {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        { id: 1, title: "Lead 1", status: "Todo" },
        { id: 2, title: "Lead 2", status: "In Progress" },
        { id: 3, title: "Lead 3", status: "Done" },
      ]);
    }, 800);
  });
}
