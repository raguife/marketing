export default function KanbanCard({ card }) {
  return (
    <div className="kanban-card">
      <p>{card.title}</p>
    </div>
  );
}
