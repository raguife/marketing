import KanbanCard from "./KanbanCard";

export default function KanbanColumn({ title, cards }) {
  return (
    <div className="kanban-column">
      <h2>{title}</h2>
      {cards.map((card) => (
        <KanbanCard key={card.id} card={card} />
      ))}
    </div>
  );
}
