export default function Header() {
  return (
    <header className="header">
      <h1>Raguife Gestão</h1>
    </header>
  );
}
