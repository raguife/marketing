export default function Sidebar({ onNavigate }) {
  return (
    <aside className="sidebar">
      <ul>
        <li onClick={() => onNavigate("dashboard")}>Dashboard</li>
        <li onClick={() => onNavigate("kanban")}>Kanban</li>
        <li onClick={() => onNavigate("leads")}>Leads</li>
      </ul>
    </aside>
  );
}
