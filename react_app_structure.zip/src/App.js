import { useEffect, useState } from "react";
import { AppProvider } from "./context/AppContext";
import useAppData from "./hooks/useAppData";
import { fetchData } from "./api/googleScript";
import Header from "./components/Header";
import Sidebar from "./components/Sidebar";
import Dashboard from "./pages/Dashboard";
import KanbanBoard from "./pages/KanbanBoard";
import Leads from "./pages/Leads";
import Spinner from "./components/Spinner";
import "./App.css";

function MainContent() {
  const { data, setData } = useAppData();
  const [page, setPage] = useState("dashboard");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData().then((res) => {
      setData(res);
      setLoading(false);
    });
  }, [setData]);

  if (loading) return <Spinner />;

  return (
    <div style={{ display: "flex" }}>
      <Sidebar onNavigate={setPage} />
      <main style={{ padding: "1rem", flex: 1 }}>
        {page === "dashboard" && <Dashboard />}
        {page === "kanban" && <KanbanBoard data={data} />}
        {page === "leads" && <Leads />}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Header />
      <MainContent />
    </AppProvider>
  );
}
