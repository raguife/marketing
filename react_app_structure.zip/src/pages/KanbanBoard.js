import KanbanColumn from "../components/KanbanColumn";

export default function KanbanBoard({ data }) {
  const columns = ["Todo", "In Progress", "Done"];

  return (
    <div className="kanban-board">
      {columns.map((col) => (
        <KanbanColumn
          key={col}
          title={col}
          cards={data.filter((card) => card.status === col)}
        />
      ))}
    </div>
  );
}
