export default function Dashboard() {
  return (
    <div>
      <h2>Dashboard</h2>
      <p>Bem-vindo ao painel da Raguife Gestão!</p>
    </div>
  );
}
