export default function Leads() {
  return (
    <div>
      <h2>Leads</h2>
      <p>Lista de leads cadastrados aparecerá aqui.</p>
    </div>
  );
}
